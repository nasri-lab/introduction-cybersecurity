"""
HelpDesk - Application 2/3 du lab IAM (Python / Flask)
ÉTAPE 1 : gestion des utilisateurs LOCALE (table helpdesk.users)
"""
import os
import secrets
import time
from functools import wraps

import pymysql
from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ["FLASK_SECRET"],
    SESSION_COOKIE_NAME="HELPDESKSESSID",     # un cookie distinct par application
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=False,              # True en production (HTTPS)
)


# ---------------------------------------------------------------- base de données
def connect():
    return pymysql.connect(
        host=os.environ["DB_HOST"], user=os.environ["DB_USER"], password=os.environ["DB_PASS"],
        database=os.environ["DB_NAME"], charset="utf8mb4", autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


def db():
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn:
        conn.close()


def query(sql, args=(), one=False):
    with db().cursor() as cur:
        cur.execute(sql, args)          # requêtes paramétrées : pas d'injection SQL
        rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows


def seed_users():
    """Comptes initiaux (mots de passe DIFFÉRENTS de ceux de BiblioGI !)."""
    for attempt in range(30):
        try:
            conn = connect()
            break
        except pymysql.err.OperationalError:
            time.sleep(2)
    else:
        raise RuntimeError("MySQL injoignable")
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) AS n FROM users")
        if cur.fetchone()["n"] == 0:
            seed = [
                ("admin", "Administrateur HelpDesk", "Admin#Help1", 1, 1),
                ("alice", "Alice Martin", "Alice2026!", 0, 0),
                ("carol", "Carol Benali", "Carol-Support9", 0, 1),
            ]
            for login, name, pwd, is_admin, is_staff in seed:
                cur.execute(
                    "INSERT INTO users (login, full_name, pwd, is_admin, is_staff) VALUES (%s,%s,%s,%s,%s)",
                    (login, name, generate_password_hash(pwd), is_admin, is_staff),
                )
    conn.close()


seed_users()


# ---------------------------------------------------------------- sécurité
def current_user():
    return session.get("user")


def login_required(view):
    @wraps(view)
    def wrapper(*a, **kw):
        if not current_user():
            return redirect(url_for("login"))
        return view(*a, **kw)
    return wrapper


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapper(*a, **kw):
        if not current_user()["is_admin"]:
            abort(403)
        return view(*a, **kw)
    return wrapper


@app.before_request
def csrf_protect():
    session.setdefault("csrf", secrets.token_hex(32))
    if request.method == "POST" and not secrets.compare_digest(
        session["csrf"], request.form.get("csrf", "")
    ):
        abort(400, "Jeton CSRF invalide")


@app.context_processor
def inject():
    return {"user": current_user(), "csrf": session.get("csrf", "")}


# ---------------------------------------------------------------- routes
@app.route("/", methods=["GET", "POST"])
@login_required
def index():
    u = current_user()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "new":
            subject = request.form.get("subject", "").strip()
            body = request.form.get("body", "").strip()
            if subject and body:
                query("INSERT INTO tickets (author_id, subject, body) VALUES (%s,%s,%s)", (u["id"], subject, body))
                flash("Ticket créé.", "ok")
        elif action == "close" and (u["is_staff"] or u["is_admin"]):
            query("UPDATE tickets SET status='fermé' WHERE id=%s", (int(request.form["id"]),))
            flash("Ticket fermé.", "ok")
        return redirect(url_for("index"))

    # Contrôle d'accès : un utilisateur ne voit que SES tickets, le staff voit tout
    if u["is_staff"] or u["is_admin"]:
        tickets = query("SELECT t.*, u.login FROM tickets t JOIN users u ON u.id=t.author_id ORDER BY t.id DESC")
    else:
        tickets = query("SELECT t.*, u.login FROM tickets t JOIN users u ON u.id=t.author_id "
                        "WHERE t.author_id=%s ORDER BY t.id DESC", (u["id"],))
    return render_template("index.html", tickets=tickets)


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        row = query("SELECT * FROM users WHERE login=%s", (request.form.get("login", "").strip(),), one=True)
        if row and check_password_hash(row["pwd"], request.form.get("password", "")):
            csrf = session.get("csrf")
            session.clear()                       # nouvelle session après authentification
            session["csrf"] = csrf
            session["user"] = {"id": row["id"], "login": row["login"], "name": row["full_name"],
                               "is_admin": bool(row["is_admin"]), "is_staff": bool(row["is_staff"])}
            flash(f"Bienvenue {row['full_name']} !", "ok")
            return redirect(url_for("index"))
        error = "Identifiants invalides."
    return render_template("login.html", error=error)


@app.route("/register", methods=["GET", "POST"])
def register():
    errors = []
    if request.method == "POST":
        login_ = request.form.get("login", "").strip().lower()
        name = request.form.get("full_name", "").strip()
        pwd = request.form.get("password", "")
        # Politique de mot de passe PROPRE à HelpDesk : 8 caractères + 1 chiffre
        if not (3 <= len(login_) <= 30 and login_.replace(".", "").replace("-", "").isalnum()):
            errors.append("Login : 3 à 30 caractères alphanumériques.")
        if not name:
            errors.append("Nom complet obligatoire.")
        if len(pwd) < 8 or not any(c.isdigit() for c in pwd):
            errors.append("Mot de passe : 8 caractères minimum dont un chiffre.")
        if not errors:
            try:
                query("INSERT INTO users (login, full_name, pwd) VALUES (%s,%s,%s)",
                      (login_, name, generate_password_hash(pwd)))
                flash("Compte créé, connectez-vous.", "ok")
                return redirect(url_for("login"))
            except pymysql.err.IntegrityError:
                errors.append("Ce login existe déjà.")
    return render_template("register.html", errors=errors)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/admin/users", methods=["GET", "POST"])
@admin_required
def admin_users():
    me = current_user()
    if request.method == "POST":
        uid = int(request.form["id"])
        if uid == me["id"]:
            flash("Impossible de modifier votre propre compte.", "err")
        elif request.form["action"] == "toggle_admin":
            query("UPDATE users SET is_admin = 1 - is_admin WHERE id=%s", (uid,))
            flash("Droit administrateur modifié.", "ok")
        elif request.form["action"] == "toggle_staff":
            query("UPDATE users SET is_staff = 1 - is_staff WHERE id=%s", (uid,))
            flash("Droit support modifié.", "ok")
        elif request.form["action"] == "delete":
            query("DELETE FROM users WHERE id=%s", (uid,))
            flash("Compte supprimé.", "ok")
        return redirect(url_for("admin_users"))
    users = query("SELECT id, login, full_name, is_admin, is_staff, created_at FROM users ORDER BY id")
    return render_template("admin.html", users=users)


@app.errorhandler(403)
def forbidden(_e):
    return render_template("base.html", content="403 - Accès réservé aux administrateurs."), 403


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
