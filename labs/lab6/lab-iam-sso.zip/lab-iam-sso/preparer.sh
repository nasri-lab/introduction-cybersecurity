#!/usr/bin/env bash
# Télécharge à l'avance toutes les images Docker du lab (étapes 1 à 3)
# puis construit les applications de l'étape 1. Usage : bash preparer.sh
set -euo pipefail
cd "$(dirname "$0")"
for img in mysql:8.4 adminer:latest quay.io/keycloak/keycloak:26.4 \
           php:8.3-apache python:3.12-slim nicolaka/netshoot:latest; do
  docker pull "$img"
done
docker pull --platform linux/amd64 osixia/openldap:1.5.0
docker pull --platform linux/amd64 osixia/phpldapadmin:0.9.0
docker compose build
echo "Préparation terminée."
