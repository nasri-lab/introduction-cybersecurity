-- =====================================================================
--  ÉTAPE 1 - Trois bases, trois comptes MySQL, trois tables "users"
--  Principe du moindre privilège : chaque application n'accède qu'à SA base.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS biblio   CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS helpdesk CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS intragi  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'biblio_user'@'%'   IDENTIFIED BY 'biblio_pass';
CREATE USER IF NOT EXISTS 'helpdesk_user'@'%' IDENTIFIED BY 'helpdesk_pass';
CREATE USER IF NOT EXISTS 'intragi_user'@'%'  IDENTIFIED BY 'intragi_pass';

GRANT SELECT, INSERT, UPDATE, DELETE ON biblio.*   TO 'biblio_user'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON helpdesk.* TO 'helpdesk_user'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON intragi.*  TO 'intragi_user'@'%';
FLUSH PRIVILEGES;

-- ---------------------------------------------------------------------
--  APP 1 : BiblioGI (PHP) - mots de passe bcrypt (password_hash)
-- ---------------------------------------------------------------------
USE biblio;

CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  email         VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('etudiant','enseignant','admin') NOT NULL DEFAULT 'etudiant',
  active        TINYINT(1) NOT NULL DEFAULT 1,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login    DATETIME NULL
);

CREATE TABLE books (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(200) NOT NULL,
  author      VARCHAR(120) NOT NULL,
  borrowed_by INT NULL,
  borrowed_at DATETIME NULL,
  FOREIGN KEY (borrowed_by) REFERENCES users(id) ON DELETE SET NULL
);

INSERT INTO books (title, author) VALUES
 ('Applied Cryptography', 'Bruce Schneier'),
 ('The Web Application Hacker''s Handbook', 'D. Stuttard, M. Pinto'),
 ('Sécurité informatique - Principes et méthodes', 'L. Bloch, C. Wolfhugel'),
 ('Hacking: The Art of Exploitation', 'Jon Erickson'),
 ('Security Engineering', 'Ross Anderson'),
 ('LDAP System Administration', 'Gerald Carter');
-- Les utilisateurs de BiblioGI sont créés au 1er démarrage par l'application (inc/bootstrap.php)

-- ---------------------------------------------------------------------
--  APP 2 : HelpDesk (Python/Flask) - mots de passe Werkzeug (scrypt/pbkdf2)
-- ---------------------------------------------------------------------
USE helpdesk;

CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  login         VARCHAR(50)  NOT NULL UNIQUE,      -- remarquez : "login" et non "username"
  full_name     VARCHAR(120) NOT NULL,
  pwd           VARCHAR(255) NOT NULL,
  is_admin      TINYINT(1)   NOT NULL DEFAULT 0,   -- et ici, pas de rôles mais un booléen...
  is_staff      TINYINT(1)   NOT NULL DEFAULT 0,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tickets (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  author_id  INT NOT NULL,
  subject    VARCHAR(200) NOT NULL,
  body       TEXT NOT NULL,
  status     ENUM('ouvert','fermé') NOT NULL DEFAULT 'ouvert',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
);
-- Les utilisateurs de HelpDesk sont créés au 1er démarrage par l'application (app.py)

-- ---------------------------------------------------------------------
--  APP 3 : IntraGI (PHP) - ⚠ VOLONTAIREMENT VULNÉRABLE : MD5 non salé
-- ---------------------------------------------------------------------
USE intragi;

CREATE TABLE users (
  uid          VARCHAR(50)  PRIMARY KEY,
  display_name VARCHAR(120) NOT NULL,
  mail         VARCHAR(120) NOT NULL,
  phone        VARCHAR(30)  NULL,
  job_title    VARCHAR(80)  NULL,
  password_md5 CHAR(32)     NOT NULL,
  is_admin     TINYINT(1)   NOT NULL DEFAULT 0
);

CREATE TABLE news (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  title      VARCHAR(200) NOT NULL,
  body       TEXT NOT NULL,
  author_uid VARCHAR(50) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (uid, display_name, mail, phone, job_title, password_md5, is_admin) VALUES
 ('rh_admin', 'Service RH',     'rh@gi4.lab',    '+212 5 22 00 00 01', 'Responsable RH', MD5('rh2023'),   1),
 ('alice',    'Alice Martin',   'alice@gi4.lab', '+212 6 61 11 11 11', 'Étudiante GI4',  MD5('alice'),    0),
 ('bob',      'Bob Durand',     'bob@gi4.lab',   '+212 6 62 22 22 22', 'Enseignant',     MD5('123456'),   0),
 ('mehdi',    'Mehdi El Amrani','mehdi@gi4.lab', '+212 6 63 33 33 33', 'Ancien stagiaire (parti en juin)', MD5('password'), 0);

INSERT INTO news (title, body, author_uid) VALUES
 ('Bienvenue sur IntraGI', 'L''intranet de l''école : annuaire et actualités.', 'rh_admin'),
 ('Coupure réseau samedi', 'Maintenance du cœur de réseau samedi de 8h à 12h.', 'rh_admin');
