<?php
require __DIR__ . '/inc/bootstrap.php';
$u = current_user();

// --- Actions (POST) -----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'borrow' || $action === 'return') {
        $u = require_login();
        $id = (int) ($_POST['book_id'] ?? 0);
        if ($action === 'borrow') {
            $st = db()->prepare('UPDATE books SET borrowed_by=?, borrowed_at=NOW() WHERE id=? AND borrowed_by IS NULL');
            $st->execute([$u['id'], $id]);
            flash($st->rowCount() ? 'Livre emprunté.' : 'Livre indisponible.', $st->rowCount() ? 'ok' : 'err');
        } else {
            // Contrôle d'accès : on ne rend que SES livres (sauf admin)
            $sql = $u['role'] === 'admin'
                ? 'UPDATE books SET borrowed_by=NULL, borrowed_at=NULL WHERE id=?'
                : 'UPDATE books SET borrowed_by=NULL, borrowed_at=NULL WHERE id=? AND borrowed_by=' . (int) $u['id'];
            db()->prepare($sql)->execute([$id]);
            flash('Livre rendu.');
        }
    } elseif ($action === 'add') {
        require_role('admin', 'enseignant');
        $title = trim($_POST['title'] ?? ''); $author = trim($_POST['author'] ?? '');
        if ($title !== '' && $author !== '') {
            db()->prepare('INSERT INTO books (title, author) VALUES (?,?)')->execute([$title, $author]);
            flash('Livre ajouté au catalogue.');
        }
    }
    header('Location: /'); exit;
}

$books = db()->query('SELECT b.*, u.username AS borrower FROM books b LEFT JOIN users u ON u.id=b.borrowed_by ORDER BY b.title')->fetchAll();

render_header('Catalogue');
?>
<div class="card">
  <h2>Catalogue de la bibliothèque</h2>
  <?php if (!$u): ?><p class="muted">Connectez-vous pour emprunter un livre.</p><?php endif; ?>
  <table>
    <tr><th>Titre</th><th>Auteur</th><th>État</th><th></th></tr>
    <?php foreach ($books as $b): ?>
    <tr>
      <td><?= e($b['title']) ?></td>
      <td><?= e($b['author']) ?></td>
      <td><?= $b['borrowed_by'] ? 'Emprunté par <b>' . e($b['borrower']) . '</b>' : '<span class="badge">Disponible</span>' ?></td>
      <td>
        <?php if ($u && !$b['borrowed_by']): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="borrow">
          <input type="hidden" name="book_id" value="<?= (int) $b['id'] ?>"><button>Emprunter</button></form>
        <?php elseif ($u && ((int) $b['borrowed_by'] === (int) $u['id'] || $u['role'] === 'admin')): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="return">
          <input type="hidden" name="book_id" value="<?= (int) $b['id'] ?>"><button>Rendre</button></form>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php if ($u && in_array($u['role'], ['admin', 'enseignant'], true)): ?>
<div class="card">
  <h3>Ajouter un livre <span class="badge">enseignant / admin</span></h3>
  <form method="post" style="display:flex;gap:8px;flex-wrap:wrap"><?= csrf_field() ?>
    <input type="hidden" name="action" value="add">
    <input name="title" placeholder="Titre" required><input name="author" placeholder="Auteur" required>
    <button>Ajouter</button>
  </form>
</div>
<?php endif; ?>
<?php render_footer();
