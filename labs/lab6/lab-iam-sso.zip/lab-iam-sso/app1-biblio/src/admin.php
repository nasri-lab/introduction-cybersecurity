<?php
/* Gestion des utilisateurs (RBAC local) : réservé au rôle admin */
require __DIR__ . '/inc/bootstrap.php';
$me = require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    if ($id === $me['id']) { flash('Vous ne pouvez pas modifier votre propre compte ici.', 'err'); header('Location: /admin.php'); exit; }
    switch ($_POST['action'] ?? '') {
        case 'role':
            $role = $_POST['role'] ?? '';
            if (in_array($role, ['etudiant', 'enseignant', 'admin'], true)) {
                db()->prepare('UPDATE users SET role=? WHERE id=?')->execute([$role, $id]);
                flash('Rôle mis à jour.');
            }
            break;
        case 'toggle':
            db()->prepare('UPDATE users SET active = 1 - active WHERE id=?')->execute([$id]);
            flash('Statut du compte modifié.');
            break;
        case 'reset':
            $tmp = bin2hex(random_bytes(4));
            db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($tmp, PASSWORD_DEFAULT), $id]);
            flash("Mot de passe réinitialisé. Mot de passe temporaire : $tmp");
            break;
        case 'delete':
            db()->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
            flash('Compte supprimé.');
            break;
    }
    header('Location: /admin.php'); exit;
}

$users = db()->query('SELECT id, username, email, role, active, created_at, last_login FROM users ORDER BY id')->fetchAll();
render_header('Utilisateurs');
?>
<div class="card">
  <h2>Gestion des utilisateurs de BiblioGI</h2>
  <p class="muted">Ces comptes n'existent <b>que</b> dans BiblioGI.</p>
  <table>
    <tr><th>#</th><th>Utilisateur</th><th>E-mail</th><th>Rôle</th><th>Actif</th><th>Dernière connexion</th><th>Actions</th></tr>
    <?php foreach ($users as $x): ?>
    <tr>
      <td><?= (int) $x['id'] ?></td>
      <td><?= e($x['username']) ?></td>
      <td><?= e($x['email']) ?></td>
      <td>
        <form method="post" style="display:flex;gap:4px"><?= csrf_field() ?>
          <input type="hidden" name="action" value="role"><input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
          <select name="role">
            <?php foreach (['etudiant', 'enseignant', 'admin'] as $r): ?>
              <option <?= $x['role'] === $r ? 'selected' : '' ?>><?= $r ?></option>
            <?php endforeach; ?>
          </select><button>OK</button>
        </form>
      </td>
      <td><?= $x['active'] ? '✅' : '⛔' ?></td>
      <td class="muted"><?= e($x['last_login'] ?? '-') ?></td>
      <td style="display:flex;gap:4px;flex-wrap:wrap">
        <?php foreach (['toggle' => 'Activer/Désactiver', 'reset' => 'Réinit. MDP', 'delete' => 'Supprimer'] as $a => $label): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="<?= $a ?>">
            <input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
            <button class="<?= $a === 'delete' ? 'danger' : '' ?>"><?= $label ?></button></form>
        <?php endforeach; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php render_footer();
