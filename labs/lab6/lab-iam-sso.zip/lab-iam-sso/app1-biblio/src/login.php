<?php
/* Authentification LOCALE : l'application vérifie elle-même le mot de passe */
require __DIR__ . '/inc/bootstrap.php';

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $st = db()->prepare('SELECT * FROM users WHERE username = ?');
    $st->execute([$username]);
    $user = $st->fetch();

    // password_verify : comparaison à temps constant du hash bcrypt
    if ($user && $user['active'] && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);           // contre la fixation de session
        $_SESSION['user'] = ['id' => (int) $user['id'], 'username' => $user['username'], 'role' => $user['role']];
        db()->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$user['id']]);
        flash('Bienvenue ' . $user['username'] . ' !');
        header('Location: /'); exit;
    }
    // Message générique : ne pas révéler si le compte existe
    $error = 'Identifiants invalides.';
}

render_header('Connexion');
?>
<div class="card">
  <h2>Connexion à BiblioGI</h2>
  <?php if ($error): ?><div class="alert err"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <input name="username" placeholder="Nom d'utilisateur" required autofocus>
    <input name="password" type="password" placeholder="Mot de passe" required>
    <button>Se connecter</button>
  </form>
  <p class="muted">Pas de compte ? <a href="/register.php">Inscrivez-vous</a>.</p>
</div>
<?php render_footer();
