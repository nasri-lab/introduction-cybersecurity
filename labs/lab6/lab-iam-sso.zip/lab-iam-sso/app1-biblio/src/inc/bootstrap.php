<?php
/* =====================================================================
 *  BiblioGI - bootstrap commun (session, base de données, helpers)
 *  ÉTAPE 1 : gestion des utilisateurs LOCALE (table biblio.users)
 * ===================================================================== */
declare(strict_types=1);

const APP_NAME  = 'BiblioGI';
const APP_COLOR = '#1d4ed8';

// --- Session durcie -----------------------------------------------------
session_name('BIBLIOSESSID');            // un cookie distinct par application
session_set_cookie_params([
    'httponly' => true,                  // inaccessible au JavaScript (XSS)
    'samesite' => 'Lax',                 // limite le CSRF
    'secure'   => false,                 // true en production (HTTPS)
]);
session_start();

// --- Base de données ----------------------------------------------------
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', getenv('DB_HOST'), getenv('DB_NAME'));
        $pdo = new PDO($dsn, getenv('DB_USER'), getenv('DB_PASS'), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,   // vraies requêtes préparées
        ]);
    }
    return $pdo;
}

// Comptes initiaux créés au premier lancement (mots de passe hachés en bcrypt)
function seed_users(): void {
    if ((int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn() > 0) return;
    $seed = [
        ['admin_biblio', 'biblio@gi4.lab', 'Biblio@2026', 'admin'],
        ['alice',        'alice@gi4.lab',  'alice123',    'etudiant'],
        ['bob',          'bob@gi4.lab',    'Bob!2024',    'enseignant'],
    ];
    $st = db()->prepare('INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?,?)');
    foreach ($seed as [$u, $m, $p, $r]) {
        $st->execute([$u, $m, password_hash($p, PASSWORD_DEFAULT), $r]);
    }
}
seed_users();

// --- Helpers ------------------------------------------------------------
function e(?string $s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }

function current_user(): ?array { return $_SESSION['user'] ?? null; }

function require_login(): array {
    $u = current_user();
    if (!$u) { header('Location: /login.php'); exit; }
    return $u;
}

function require_role(string ...$roles): array {
    $u = require_login();
    if (!in_array($u['role'], $roles, true)) { http_response_code(403); render_header('Accès refusé');
        echo '<div class="alert err">403 - Votre rôle (' . e($u['role']) . ') ne permet pas cette action.</div>';
        render_footer(); exit; }
    return $u;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(400); exit('Jeton CSRF invalide'); }
}

function flash(?string $msg = null, string $type = 'ok'): ?array {
    if ($msg !== null) { $_SESSION['flash'] = [$type, $msg]; return null; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}

// --- Gabarit HTML -------------------------------------------------------
function render_header(string $title): void {
    $u = current_user();
    $c = APP_COLOR;
    $t = e($title);
    echo <<<HTML
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{$t} - BiblioGI</title>
<style>
 :root{--c:{$c}} *{box-sizing:border-box} body{margin:0;font-family:system-ui,Segoe UI,Roboto,sans-serif;background:#f4f6fb;color:#1f2937}
 header{background:var(--c);color:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
 header a{color:#fff;margin-left:14px;text-decoration:none;font-weight:500} header .brand{font-size:1.3em;font-weight:700}
 main{max-width:920px;margin:24px auto;padding:0 16px} .card{background:#fff;border-radius:10px;padding:20px;box-shadow:0 1px 3px #0002;margin-bottom:18px}
 table{width:100%;border-collapse:collapse} th,td{text-align:left;padding:8px;border-bottom:1px solid #e5e7eb} th{background:#f9fafb}
 input,select,button,textarea{font:inherit;padding:8px 10px;border:1px solid #cbd5e1;border-radius:6px}
 button,.btn{background:var(--c);color:#fff;border:0;cursor:pointer;padding:8px 14px;border-radius:6px;text-decoration:none;display:inline-block}
 button.danger{background:#b91c1c} .badge{padding:2px 8px;border-radius:99px;font-size:.8em;background:#e0e7ff;color:#3730a3}
 .alert{padding:10px 14px;border-radius:6px;margin-bottom:14px} .ok{background:#dcfce7;color:#166534} .err{background:#fee2e2;color:#991b1b}
 form.stack{display:grid;gap:10px;max-width:360px} .muted{color:#6b7280;font-size:.9em} pre{background:#0f172a;color:#e2e8f0;padding:12px;border-radius:8px;overflow:auto;font-size:.85em}
</style></head><body>
<header><span class="brand">📚 BiblioGI</span><nav>
HTML;
    echo '<a href="/">Catalogue</a>';
    if ($u) {
        if ($u['role'] === 'admin') echo '<a href="/admin.php">Utilisateurs</a>';
        echo '<a href="/logout.php">Déconnexion (' . e($u['username']) . ' · ' . e($u['role']) . ')</a>';
    } else {
        echo '<a href="/login.php">Connexion</a><a href="/register.php">Inscription</a>';
    }
    echo '</nav></header><main>';
    if ($f = flash()) echo '<div class="alert ' . e($f[0]) . '">' . e($f[1]) . '</div>';
}

function render_footer(): void {
    echo '<p class="muted">Lab IAM - Application 1/3 - authentification <b>locale</b> (base <code>biblio.users</code>)</p></main></body></html>';
}
