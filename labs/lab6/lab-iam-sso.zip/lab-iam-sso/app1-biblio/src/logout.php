<?php
require __DIR__ . '/inc/bootstrap.php';
$_SESSION = [];
session_destroy();
setcookie(session_name(), '', ['expires' => time() - 3600, 'path' => '/']);
header('Location: /');
