<?php
/* Inscription LOCALE : n'importe qui peut se créer un compte (auto-provisioning) */
require __DIR__ . '/inc/bootstrap.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!preg_match('/^[a-z0-9._-]{3,30}$/', $username)) $errors[] = "Nom d'utilisateur : 3 à 30 caractères [a-z0-9._-].";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))      $errors[] = 'Adresse e-mail invalide.';
    // Politique de mot de passe PROPRE à BiblioGI : 6 caractères minimum
    if (strlen($password) < 6)                            $errors[] = 'Mot de passe : 6 caractères minimum.';

    if (!$errors) {
        try {
            db()->prepare('INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?,"etudiant")')
                ->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT)]);
            flash('Compte créé, vous pouvez vous connecter.');
            header('Location: /login.php'); exit;
        } catch (PDOException $ex) {
            $errors[] = 'Ce nom d\'utilisateur est déjà pris.';
        }
    }
}

render_header('Inscription');
?>
<div class="card">
  <h2>Créer un compte BiblioGI</h2>
  <?php foreach ($errors as $er): ?><div class="alert err"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <input name="username" placeholder="Nom d'utilisateur" required>
    <input name="email" type="email" placeholder="E-mail" required>
    <input name="password" type="password" placeholder="Mot de passe (6 car. min.)" required>
    <button>Créer mon compte</button>
  </form>
  <p class="muted">Les nouveaux comptes reçoivent le rôle <b>etudiant</b>.</p>
</div>
<?php render_footer();
