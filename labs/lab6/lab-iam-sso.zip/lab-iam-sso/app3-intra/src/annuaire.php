<?php
/* Annuaire du personnel : à l'étape 1, il est tiré de la table locale intragi.users */
require __DIR__ . '/inc/bootstrap.php';
require_login();

$q = trim($_GET['q'] ?? '');
$st = db()->prepare('SELECT uid, display_name, mail, phone, job_title FROM users
                     WHERE display_name LIKE ? OR uid LIKE ? ORDER BY display_name');
$st->execute(["%$q%", "%$q%"]);
$people = $st->fetchAll();
render_header('Annuaire');
?>
<div class="card">
  <h2>Annuaire</h2>
  <form method="get" style="display:flex;gap:8px;margin-bottom:12px">
    <input name="q" value="<?= e($q) ?>" placeholder="Rechercher un nom..."><button>Rechercher</button>
  </form>
  <table>
    <tr><th>Nom</th><th>Identifiant</th><th>Fonction</th><th>E-mail</th><th>Téléphone</th></tr>
    <?php foreach ($people as $p): ?>
    <tr><td><?= e($p['display_name']) ?></td><td><code><?= e($p['uid']) ?></code></td><td><?= e($p['job_title']) ?></td>
        <td><?= e($p['mail']) ?></td><td><?= e($p['phone']) ?></td></tr>
    <?php endforeach; ?>
  </table>
</div>
<?php render_footer();
