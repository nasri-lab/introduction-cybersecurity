<?php
/* Authentification LOCALE d'IntraGI.
 * ⚠ FAILLE VOLONTAIRE (Hack & Fix) : le mot de passe est comparé à un MD5 NON SALÉ. */
require __DIR__ . '/inc/bootstrap.php';

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $uid = trim($_POST['uid'] ?? '');
    $st = db()->prepare('SELECT * FROM users WHERE uid = ?');
    $st->execute([$uid]);
    $user = $st->fetch();

    if ($user && hash_equals($user['password_md5'], md5($_POST['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['uid' => $user['uid'], 'name' => $user['display_name'], 'is_admin' => (bool) $user['is_admin']];
        header('Location: /'); exit;
    }
    $error = 'Identifiants invalides.';
}
render_header('Connexion');
?>
<div class="card">
  <h2>Connexion à l'intranet</h2>
  <?php if ($error): ?><div class="alert err"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack"><?= csrf_field() ?>
    <input name="uid" placeholder="Identifiant" required autofocus>
    <input name="password" type="password" placeholder="Mot de passe" required>
    <button>Se connecter</button>
  </form>
  <p class="muted">Pas d'inscription en libre-service : les comptes sont créés par le service RH.</p>
</div>
<?php render_footer();
