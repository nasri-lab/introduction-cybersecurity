<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $u['is_admin']) {
    csrf_check();
    $title = trim($_POST['title'] ?? ''); $body = trim($_POST['body'] ?? '');
    if ($title !== '' && $body !== '') {
        db()->prepare('INSERT INTO news (title, body, author_uid) VALUES (?,?,?)')->execute([$title, $body, $u['uid']]);
        flash('Actualité publiée.');
    }
    header('Location: /'); exit;
}
$news = db()->query('SELECT * FROM news ORDER BY id DESC')->fetchAll();
render_header('Actualités');
?>
<div class="card"><h2>Bonjour <?= e($u['name']) ?> 👋</h2><p class="muted">Dernières actualités de l'école.</p></div>
<?php foreach ($news as $n): ?>
  <div class="card"><h3><?= e($n['title']) ?></h3><p><?= nl2br(e($n['body'])) ?></p>
  <p class="muted">Par <?= e($n['author_uid']) ?> - <?= e($n['created_at']) ?></p></div>
<?php endforeach; ?>
<?php if ($u['is_admin']): ?>
<div class="card"><h3>Publier une actualité <span class="badge">RH</span></h3>
  <form method="post" class="stack"><?= csrf_field() ?>
    <input name="title" placeholder="Titre" required><textarea name="body" rows="3" placeholder="Texte" required></textarea>
    <button>Publier</button></form></div>
<?php endif; ?>
<?php render_footer();
