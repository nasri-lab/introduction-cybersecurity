<?php
/* =====================================================================
 *  IntraGI - bootstrap commun
 *  ÉTAPE 1 : gestion des utilisateurs LOCALE (table intragi.users)
 *  ⚠ Application VOLONTAIREMENT faible : mots de passe en MD5 non salé
 * ===================================================================== */
declare(strict_types=1);

session_name('INTRASESSID');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => false]);
session_start();

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', getenv('DB_HOST'), getenv('DB_NAME'));
        $pdo = new PDO($dsn, getenv('DB_USER'), getenv('DB_PASS'), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

function e(?string $s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): array {
    if (!current_user()) { header('Location: /login.php'); exit; }
    return current_user();
}
function require_admin(): array {
    $u = require_login();
    if (!$u['is_admin']) { http_response_code(403); render_header('Accès refusé');
        echo '<div class="alert err">403 - Réservé au service RH.</div>'; render_footer(); exit; }
    return $u;
}
function csrf_field(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . $_SESSION['csrf'] . '">';
}
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(400); exit('Jeton CSRF invalide'); }
}
function flash(?string $msg = null, string $type = 'ok'): ?array {
    if ($msg !== null) { $_SESSION['flash'] = [$type, $msg]; return null; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}

function render_header(string $title): void {
    $u = current_user();
    $t = e($title);
    echo <<<HTML
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{$t} - IntraGI</title>
<style>
 :root{--c:#047857} *{box-sizing:border-box} body{margin:0;font-family:system-ui,Segoe UI,Roboto,sans-serif;background:#f0fdf4;color:#1f2937}
 header{background:var(--c);color:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
 header a{color:#fff;margin-left:14px;text-decoration:none;font-weight:500} header .brand{font-size:1.3em;font-weight:700}
 main{max-width:920px;margin:24px auto;padding:0 16px} .card{background:#fff;border-radius:10px;padding:20px;box-shadow:0 1px 3px #0002;margin-bottom:18px}
 table{width:100%;border-collapse:collapse} th,td{text-align:left;padding:8px;border-bottom:1px solid #e5e7eb} th{background:#f9fafb}
 input,select,button,textarea{font:inherit;padding:8px 10px;border:1px solid #cbd5e1;border-radius:6px}
 button,.btn{background:var(--c);color:#fff;border:0;cursor:pointer;padding:8px 14px;border-radius:6px;text-decoration:none;display:inline-block}
 button.danger{background:#b91c1c} .badge{padding:2px 8px;border-radius:99px;font-size:.8em;background:#d1fae5;color:#065f46}
 .alert{padding:10px 14px;border-radius:6px;margin-bottom:14px} .ok{background:#dcfce7;color:#166534} .err{background:#fee2e2;color:#991b1b}
 form.stack{display:grid;gap:10px;max-width:420px} .muted{color:#6b7280;font-size:.9em} code{background:#ecfdf5;padding:1px 5px;border-radius:4px}
</style></head><body>
<header><span class="brand">🏢 IntraGI</span><nav>
HTML;
    if ($u) {
        echo '<a href="/">Actualités</a><a href="/annuaire.php">Annuaire</a>';
        if ($u['is_admin']) echo '<a href="/admin.php">Comptes (RH)</a>';
        echo '<a href="/logout.php">Déconnexion (' . e($u['uid']) . ')</a>';
    } else {
        echo '<a href="/login.php">Connexion</a>';
    }
    echo '</nav></header><main>';
    if ($f = flash()) echo '<div class="alert ' . e($f[0]) . '">' . e($f[1]) . '</div>';
}

function render_footer(): void {
    echo '<p class="muted">Lab IAM - Application 3/3 - authentification <b>locale</b> (base <code>intragi.users</code>)</p></main></body></html>';
}
