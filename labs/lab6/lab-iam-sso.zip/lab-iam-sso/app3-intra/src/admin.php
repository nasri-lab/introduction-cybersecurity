<?php
/* Création / suppression des comptes par le service RH */
require __DIR__ . '/inc/bootstrap.php';
$me = require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $uid = strtolower(trim($_POST['uid'] ?? ''));
        if (preg_match('/^[a-z0-9._-]{2,30}$/', $uid) && ($_POST['password'] ?? '') !== '') {
            try {
                db()->prepare('INSERT INTO users (uid, display_name, mail, phone, job_title, password_md5, is_admin) VALUES (?,?,?,?,?,?,?)')
                    ->execute([$uid, trim($_POST['display_name']), trim($_POST['mail']), trim($_POST['phone']),
                               trim($_POST['job_title']), md5($_POST['password']), isset($_POST['is_admin']) ? 1 : 0]);
                flash("Compte $uid créé.");
            } catch (PDOException $ex) { flash('Identifiant déjà utilisé.', 'err'); }
        } else { flash('Identifiant ou mot de passe invalide.', 'err'); }
    } elseif ($action === 'delete' && ($_POST['uid'] ?? '') !== $me['uid']) {
        db()->prepare('DELETE FROM users WHERE uid=?')->execute([$_POST['uid']]);
        flash('Compte supprimé.');
    }
    header('Location: /admin.php'); exit;
}
$users = db()->query('SELECT uid, display_name, job_title, password_md5, is_admin FROM users ORDER BY uid')->fetchAll();
render_header('Comptes');
?>
<div class="card">
  <h2>Comptes IntraGI</h2>
  <table>
    <tr><th>Identifiant</th><th>Nom</th><th>Fonction</th><th>Empreinte stockée</th><th>RH</th><th></th></tr>
    <?php foreach ($users as $x): ?>
    <tr><td><code><?= e($x['uid']) ?></code></td><td><?= e($x['display_name']) ?></td><td><?= e($x['job_title']) ?></td>
      <td><code style="font-size:.75em"><?= e($x['password_md5']) ?></code></td><td><?= $x['is_admin'] ? '✅' : '' ?></td>
      <td><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="delete">
        <input type="hidden" name="uid" value="<?= e($x['uid']) ?>"><button class="danger">Supprimer</button></form></td></tr>
    <?php endforeach; ?>
  </table>
</div>
<div class="card">
  <h3>Créer un compte</h3>
  <form method="post" class="stack"><?= csrf_field() ?><input type="hidden" name="action" value="create">
    <input name="uid" placeholder="Identifiant (ex. jdupont)" required>
    <input name="display_name" placeholder="Nom affiché" required>
    <input name="mail" type="email" placeholder="E-mail" required>
    <input name="phone" placeholder="Téléphone"><input name="job_title" placeholder="Fonction">
    <input name="password" type="password" placeholder="Mot de passe initial" required>
    <label><input type="checkbox" name="is_admin"> Membre du service RH (admin)</label>
    <button>Créer</button>
  </form>
</div>
<?php render_footer();
